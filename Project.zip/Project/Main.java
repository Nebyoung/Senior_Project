import java.io.FileInputStream;
import java.text.DecimalFormat;
import java.util.*;
import java.io.*;
import java.util.*;
import java.util.Map;

public class Main
{
    public static void main(String[] args)
    {
        System.out.println("Analyzing");
        int lines = 50;


        if(args.length == 0 || args.length > 2)
        {
            System.err.println("Incorrect Operation. Please execute as \"java Main final.txt *# output lines*\"");
            System.exit(1);
        }
        try
        {
            int gramCount = 6;
            String name = args[0].toString();
            if (args.length == 2)
                lines = Integer.parseInt(args[1]);
            name = name.substring(0, name.length() - 4);
            FileInputStream fstream = new FileInputStream(args[0]);
            int content;
            List<Character> text = new ArrayList<>();
            while ((content = fstream.read()) != -1)
            {
                text.add((char) content);
            }
            char[] a = new char[text.size()];
            for (int i = 0; i < text.size(); i++)
            {
                a[i] = text.get(i);
            }
            String TEXT = new String(a);
            char tmp = (char) 92;
            //int index = name.lastIndexOf(tmp);


            String temp = name + "-metaData.txt";
            try (Writer fw = new FileWriter(temp))
            {
                fw.write(String.format("%s instructions, %s bytes", Integer.toString(TEXT.length() / 3), Integer.toString(TEXT.length())));
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }



            for (int i = 1; i <= gramCount; i++)
            {
                analysis(TEXT, i, name, lines);
            }

            fstream.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void excel(String name, List<List<Pair<String, Integer>>> data, int gram)
    {
        try (Writer fw = new FileWriter(name + "-Gram_analysis.xls"))
        {

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public static void analysis(String text, int gram, String name, int lines)
    {
        String[] instructions = text.split(" ");
        HashMap<String, Integer> hMap = new HashMap<String, Integer>();
        for (int i = 0; i < instructions.length - gram; i++)
        {
            String temp = "";
            for (int j = 0; j < gram; j++)
            {
                temp += instructions[i + j];
            }

            if (hMap.containsKey(temp))
            {

                int c = hMap.get(temp);
                hMap.remove(temp);
                hMap.put(temp, c + 1);
            }
            else
            {
                hMap.put(temp, 1);
            }

        }
        List<String> letters = new ArrayList<String>();
        List<Integer> counts = new ArrayList<Integer>();
        List<Pair<String, Integer>>  results = new ArrayList<>();
        double total = 0;
        String zeroes = "";
        for (int i = 0; i < gram; i++)
        {
            zeroes = zeroes + "00";
        }
        for (Map.Entry<String, Integer> map : hMap.entrySet())
        {
            String temp = map.getKey();
            if (temp.equals(zeroes))
            {
                continue;
            }
            letters.add(temp);
            counts.add(map.getValue());
            total += map.getValue();


        }

        for (int  i = 0; i < counts.size(); i++)
        {
            Pair temp = new Pair<>(letters.get(i), counts.get(i));
            results.add(temp);
        }

        results.sort(Comparator.comparingInt(Pair::getValue));
        try (Writer fw = new FileWriter(name + "_" + gram + "-Gram_analysis.csv"))
        {
            int temp = results.size();
            for (int i = temp - 1; i >= temp - lines; i--)
           {
                fw.write((results.size() - i) + ",'" + results.get(i).getKey() + "'," + String.format( "%.2f", ((100.00 * (double) results.get(i).getValue()) / total)) + '%' + "\n");
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }

}
