from openpyxl import Workbook
import csv
import sys
import os

from openpyxl.chart import (
    LineChart,
    BarChart,
    Reference,
    Series,
)

wb = Workbook()
ws = wb.active


a = sys.argv[1];
gram = int(float(sys.argv[2]));
columns = [] # each value in each column is appended to a list
with open(a) as f:
    lines = f.read().splitlines()
#ws.append(["Count", "Instrucitons", "%"]);
for i in lines:
    temp = i.split(',');
    array = [int(float(temp[0])),temp[1],float(temp[2].strip('%'))];
    ws.append(array)
    #print(i.strip('%').split(','))

chart1 = BarChart()
chart1.type = "col"
chart1.style = 10
chart1.title = "Bar Chart"
chart1.y_axis.title = 'Percentage of Occurence'
chart1.x_axis.title = 'Instrucitons'

cats = Reference(ws, min_col=2, min_row=1, max_row=50, max_col=3)
data = Reference(ws, min_col=2, min_row=1, max_row=50)
chart1.add_data(cats, titles_from_data=True)
chart1.set_categories(data)
chart1.shape = 4
#ws.add_chart(chart1, "A10")

from copy import deepcopy

chart2 = deepcopy(chart1)
chart2.style = 11
chart2.type = "bar"
chart2.title = "Horizontal Bar Chart"

ws.add_chart(chart2, "G10")




#ws.add_chart(chart3, "A27")




#ws.add_chart(chart4, "G27")

wb.save("final_"+ str(gram) +"-Gram_Analysis_Chart.xlsx")
