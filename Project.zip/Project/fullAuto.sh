#!/bin/sh
if [ "$#" -ne 2 ]; then
  echo "Usage: $0 File.c num_data_points";
  exit 1;
fi
gcc -o alpha.o $1; od -t x1 alpha.o | cut -c8- > beta.txt; tr -d "\n" < beta.txt > final.txt; rm beta.txt;
javac Main.java;
javac Pair.java;
echo $1;
echo $2;
java Main final.txt $2;
i=1
while [ $i -le 6 ]
do
	python chart.py final_$i-Gram_analysis.csv $i;
  i=$(($i + 1));
done
