<!DOCTYPE html>
<html>
  <head>
    <title>Form Output</title>
  </head>
  <body>
    <p>Hi <?php echo htmlspecialchars($_POST['name']); ?>.</p>
    <p>You are <?php echo (int)$_POST['age']; ?> years young, you look good for a <?php echo (int)$_POST['age']; ?> year old!</p>
  </body>
</html>
